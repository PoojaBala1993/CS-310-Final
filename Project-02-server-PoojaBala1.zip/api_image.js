//
// app.post('/image/:userid', async (req, res) => {...});
//
// Uploads an image to the bucket and updates the database,
// returning the asset id assigned to this image.
//
const dbConnection = require('./database.js')
const { PutObjectCommand } = require('@aws-sdk/client-s3');
const { s3, s3_bucket_name, s3_region_name } = require('./aws.js');

const uuid = require('uuid');

exports.post_image = async (req, res) => {

  console.log("call to /image...");

  try {

    var user_id_input = req.params.userid;
    var image_name = uuid.v4();

    // console.log(user_id_input)

    var data = req.body;  // data => JS object
    var base64EncodedString = req.body.data;
    var asset_name_local = req.body.assetname;
    var bytes = Buffer.from(base64EncodedString, 'base64');



    // throw new Error("TODO: /image");
    //**************************************
    var rds_response = new Promise((resolve, reject) => {
      var sql =
        "select * from users where userid = ?";
      ;

      dbConnection.query(sql, [user_id_input], (err, result, _) => {
        if (err) {
          reject(err);
          return;
        }

        resolve(result);
      });
    });

    //
    // wait for query to resolve since we need the bucket key:
    //
    var result = await rds_response;

    // console.log(result);

    if (result.length == 0) {
      console.log("user does not exist")
      res.json({
        "message": "no such user...",
        "assetid": -1,
      });

    } else {


      var bucket_folder_name = result[0].bucketfolder;
      // console.log(result[0].bucketfolder);
      // console.log(image_name)
      image_name_updated = bucket_folder_name + "/" + image_name + ".jpg"
      console.log(image_name_updated)

      var for_upload = await s3.send(new PutObjectCommand({
        Bucket: s3_bucket_name,
        Key: image_name_updated,
        Body: bytes,
      }));

      //************   **************  *************
      var asset_db_update = new Promise((resolve, reject) => {
        var sql =
          "insert into assets (userid, assetname, bucketkey) VALUES (?, ?, ?)";


        dbConnection.query(sql, [user_id_input, asset_name_local, image_name_updated], (err, result, _) => {
          if (err) {
            reject(err);
            return;
          }

          resolve(result);
        });
      });

      var result1 = await asset_db_update;
      var asset_id_new = result1.insertId;

      //*************  **********   **************

      res.json({
        "message": "success",
        "assetid": asset_id_new,
      });

    }





    //**************************************



  }//try
  catch (err) {
    res.status(400).json({
      "message": err.message,
      "assetid": -1
    });
  }//catch

}//post
