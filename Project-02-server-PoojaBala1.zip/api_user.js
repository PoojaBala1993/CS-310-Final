//
// app.put('/user', async (req, res) => {...});
//
// Inserts a new user into the database, or if the
// user already exists (based on email) then the
// user's data is updated (name and bucket folder).
// Returns the user's userid in the database.
//
const dbConnection = require('./database.js')
const { v4: uuidv4 } = require('uuid');

exports.put_user = async (req, res) => {

  console.log("call to /user...");

  try {

    var data = req.body;  // data => JS object
    // const conn = await dbConnection();
    // console.log(data.email);
    var email_input = data.email;
    var last_name_input = data.lastname;
    var first_name_input = data.firstname;
    var bucketfolder_input = data.bucketfolder;

    // console.log(email_input, last_name_input, first_name_input, bucketfolder_input)

    var rds_response = new Promise((resolve, reject) => {
      var sql =
        "select * from users where email = ?";
      ;

      dbConnection.query(sql, [email_input], (err, result, _) => {
        if (err) {
          reject(err);
          return;
        }

        resolve(result);
      });
    });

    //
    // wait for query to resolve since we need the bucket key:
    //
    var result = await rds_response;

    // console.log(result);

    if (result.length == 0) {
      console.log("user does not exist")



      var insert_response = new Promise((resolve, reject) => {
        var sql =
          "insert into users (email, firstname, lastname, bucketfolder) VALUES (?, ?, ?, ?)";


        dbConnection.query(sql, [email_input, first_name_input, last_name_input, bucketfolder_input], (err, result, _) => {
          if (err) {
            reject(err);
            return;
          }

          resolve(result);
        });
      });

      var result1 = await insert_response;


      console.log(result1.insertId)
      res.json({
        "message": "inserted",
        "userid": result1.insertId,
      });

    } else {

      //
      var row = result[0];

      var userid = result[0].userid;
      console.log(userid);

      // var email = row["email"];
      // var bucketfolder = row["bucketfolder"];
      // var firstname = row["firstname"]
      // var lastname = row["lastname"]

      var updated_response = new Promise((resolve, reject) => {
        var sql = " UPDATE users SET firstname = ?,lastname = ?, bucketfolder = ? WHERE email = ?";


        dbConnection.query(sql, [first_name_input, last_name_input, bucketfolder_input, email_input], (err, result, _) => {
          if (err) {
            reject(err);
            return;
          }

          resolve(result);
        });
      });

      var result1 = await updated_response;

      res.json({
        "message": "updated",
        "userid": userid,
        // "em": result1.email,
        // "bu": result1.bucketfolder,
        // "fn": firstname,
        // "ln": lastname
      });

    }


  }//try
  catch (err) {
    res.status(400).json({
      "message": err.message,
      "userid": -1
    });
  }//catch

}//put
