//
// app.get('/download/:assetid', async (req, res) => {...});
//
// downloads an asset from S3 bucket and sends it back to the
// client as a base64-encoded string.
//
const dbConnection = require('./database.js')
const { GetObjectCommand } = require('@aws-sdk/client-s3');
const { s3, s3_bucket_name, s3_region_name } = require('./aws.js');

exports.get_download = async (req, res) => {

  console.log("call to /download...");

  try {

    var asset_id_input = req.params.assetid;
    // var asset_int = int(asset_id_input)
    var asset_id;
    var bucketkey_obtained;
    var sql = "Select * From assets Order By assetid;";
    var params = [];

    console.log("call to /users...");

    dbConnection.query(sql, params, async (err, rows) => {
      if (err) {
        res.status(400).json({
          "message": err.message,
          "data": []
        });
        return;
      }

      let foundAsset = "";

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        // console.log(row.assetid)

        if (row.assetid == asset_id_input) {
          foundAsset = row;
          break;
        }
      }
      // serialize data for transmission:
      if (foundAsset) {
        // serialize data for transmission:

        // res_str = str(res.json.data)
        bucketkey_obtained = foundAsset.bucketkey;
        // console.log(bucketkey_obtained)

        // var getObjectParams = s3.send(new GetObjectCommand({
        //   Bucket: s3_bucket_name,
        //   Key: bucketkey_obtained
        // }));

        var getObjectParams = {
          Bucket: s3_bucket_name,
          Key: bucketkey_obtained
        };

        var getObjectCommand = new GetObjectCommand(getObjectParams);

        var getObjectOutput = await s3.send(getObjectCommand);
        const dataBuffer = getObjectOutput.Body;

        var datastr = await dataBuffer.transformToString('base64');
        console.log(datastr)

        // console.log(`Asset ID is ${asset_id}`);
        res.json({
          "message": "success",
          "user_id": foundAsset.userid,
          "asset_name": foundAsset.assetname,
          "bucket_key": foundAsset.bucketkey,
          "data": datastr
        });

      } else {
        res.status(200).json({
          "message": "no such asset...",
          "user_id": -1,
          "asset_name": "?",
          "bucket_key": "?",
          "data": []
        });
      }

    });

    //
    // TODO: remember we did an example similar to this in class with
    // movielens database (lecture 05 on Thursday 04-13)
    //
    // MySQL in JS:
    //   https://expressjs.com/en/guide/database-integration.html#mysql
    //   https://github.com/mysqljs/mysql
    //


  }//try
  catch (err) {
    //
    // generally we end up here if we made a 
    // programming error, like undefined variable
    // or function:
    //
    res.status(400).json({
      "message": err.message,
      "user_id": -1,
      "asset_name": "?",
      "bucket_key": "?",
      "data": []
    });
  }//catch

}//get
