//
// app.get('/users', async (req, res) => {...});
//
// Return all the users from the database:
//
const dbConnection = require('./database.js')

exports.get_users = async (req, res) => {

  console.log("call to /users...");


  try {



    var sql = "Select * From users Order By userid;";
    var params = [];

    console.log("call to /users...");

    dbConnection.query(sql, params, (err, rows) => {
      if (err) {
        res.status(400).json({
          "message": err.message,
          "data": []
        });
        return;
      }

      // serialize data for transmission:
      res.json({
        "message": "success",
        "data": rows
      });

    });


  }//try
  catch (err) {
    res.status(400).json({
      "message": err.message,
      "data": []
    });
  }//catch

}//get
