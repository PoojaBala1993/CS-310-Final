//
// app.get('/bucket?startafter=bucketkey', async (req, res) => {...});
//
// Retrieves the contents of the S3 bucket and returns the 
// information about each asset to the client. Note that it
// returns 12 at a time, use startafter query parameter to pass
// the last bucketkey and get the next set of 12, and so on.
//
const { ListObjectsV2Command } = require('@aws-sdk/client-s3');
const { s3, s3_bucket_name, s3_region_name } = require('./aws.js');

exports.get_bucket = async (req, res) => {

  console.log("call to /bucket...");

  try {
    var startafter;

    if (req.query.startafter) {
      startafter = req.query.startafter;
    }
    else {
      startafter = "";
    }


    var response = await s3.send(new ListObjectsV2Command({
      Bucket: s3_bucket_name,
      MaxKeys: 12,
      StartAfter: startafter
    }));
    // var BucketItems = response.Contents;


    if (response.KeyCount == 0) {
      res.status(200).json({
        "message": "success",
        "data": []
      });
      return;
    }

    // var data = BucketItems.map((BucketItem) => {
    //   if (BucketItem.hasOwnProperty('Key')) {
    //     return {
    //       "key": BucketItem.Key,
    //       "lastmodified": BucketItem.LastModified,
    //       // "etag": BucketItem.ETag,
    //       // "size": BucketItem.Size,
    //       // "storageclass": BucketItem.StorageClass
    //     };
    //   }
    //   //     else {
    //   //   return null;
    //   // }
    // });

    res.status(200).json({
      "message": "success",
      "data": response.Contents
    });


  }//try
  catch (err) {
    res.status(400).json({
      "message": err.message,
      "data": []
    });
  }//catch

}//get
